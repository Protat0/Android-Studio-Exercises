This is a repository containing all android studio related exercises and activities, go to different branches to explore other activities
